<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Validator,Auth,Exception;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendMailable;
use Carbon\Carbon;

class UserController extends Controller
{
    public function __construct(){
    	$this->middleware('auth');
    	$this->user=new User;
    }

   public function userIndex(Request $request){
   	try{
   		$this->data['userlist']=$this->user->getUsers($request);
   		$this->date['search']=$request->search ? $request->search : "--";
   		return view('usermanagement.index',$this->data);
   	}catch(Exception $e){
   		return $e->getMessage();
   	}
   }
   public function userCreate($id=false){
   	try{
   		if($id){
   			$this->data['users']=User::find($id);
   		}else{
   			$this->data['users']=$this->getTableColumns($this->user->getTable());
   		}
   		$this->data['pagetitle']=$id ? "Update Users" : "Create Users";
   		$this->data['user_id']=$id;
   		return view('usermanagement.form',$this->data);
   	}catch(Exception $e){
   		return $e->getMessage();
   	}
   }

   public function userStore(Request $request){
   	try{
   		$this->validator($request->all(),$request->id)->validate();
   		$users=User::findorNew($request->id);
   		$users->name=trim($request->name);
   		$users->email=trim($request->email);
   		$users->mobile_no=$request->mobile_no;
   		if(!is_null($request->password)){
   			 $users->password=bcrypt($request->password);
   		}
   		$request->timestamps=$request->id  ?true : false;
   		$users->created_at=Carbon::now();
   		$users->updated_at=Carbon::now();
   		$users->save();
   		return redirect('/list-users')->with('success',$request->id ? "User Updated Successfully" : "User Created Successfully");
   	}catch(Exception $e){
   		return $e->getMessage();
   	}
   }

   protected function validator(array $data,$id)
	{
   		return Validator::make($data, [
   		'name'=>'required|string|max:50',
   		'email' => 'string|email|max:255|unique:users,email,'.$id.',id,deleted_at,NULL',
   		'mobile_no' => 'min:10|max:10|regex:/[0-9]/|unique:users,mobile_no,'.$id.',id,deleted_at,NULL',		
   		]);
	} 

   public function userDelete(Request $request){
      try{
         if($request->filled('id')){
            $user=User::find($request->id);
            $user->where('id',$request->id)->update(['deleted_at'=>Carbon::now()]);
            return redirect('/list-users')->with('success','User Deleted Successfully');
         }
      }catch(Exception $e){
         return $e->getMessage();
      }

   }

   public function eventEmail(){
      try{
         $name=Auth::user()->name;
         Mail::to('srini2093@gmail.com')->send(new SendMailable("srinivasan"));
         return 'Email is Send';
      }catch(Exception $e){
         return $e->getMessage();
      }
   }
    public function userDashoard(){
        return view('usermanagement.dashboard');
    }
}
