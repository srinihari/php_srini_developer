<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

	Route::get('/user-dashboard','UserController@userDashoard');


Route::middleware(['auth'])->group(function(){
	Route::get('list-users','UserController@userIndex');
	Route::get('/user-edit/{id}','UserController@userCreate');
	Route::get('user-creation','UserController@userCreate');
	Route::post('user-create','UserController@userStore');
	Route::post('user-delete','UserController@userDelete');
	Route::get('send-email-event','UserController@eventEmail');
});
