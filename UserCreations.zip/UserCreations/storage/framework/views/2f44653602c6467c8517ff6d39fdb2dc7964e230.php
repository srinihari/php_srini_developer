<style type="text/css">
#contextMenu {
  position: absolute;
  display: none;
}
</style>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="body">
	<div class="card">
		<div id="context_menus">
					<p><a href><b>Hi, When Right Click to Perform the Events</b></a></p>
		<?php echo Form::open(array('url'=>url('send-email-event'),'method'=>'get','id'=>'js-email-event')); ?>

		<?php echo Form::close(); ?>

		<div>
	</div>
</div>
</div>	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
 <script src="/js/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	//("div").oncontextmenu=function()
	$('#context_menus').contextmenu(function(){
		$('#js-email-event').submit();
	})
	
});


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>