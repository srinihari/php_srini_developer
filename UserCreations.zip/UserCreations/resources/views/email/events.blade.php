<div class="card">
Hi welcome to {{ $name or "---"}}
</div>
