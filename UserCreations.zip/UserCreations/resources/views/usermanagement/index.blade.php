@extends('layouts.app')
@section('title','User Management')
@section('content')
    <link href="css/toastr.css" rel="stylesheet">

<div clas="container">
<h1>List of Users</h1>
<div id="notification" style="display: none;">
  <span class="dismiss"><a title="dismiss this notification"></a></span>
</div>
	<div class='row'>

		<div class="col-sm-8 text-right">
				
			<div class="col-md-2">
				<div class="">
					<div class="col-md-10 text-right">
						<a href="{{ url('/user-creation')}}" class="btn btn-success">New User</a>
					</div>	
				</div>	
			</div>	
		<div class="clearfix"></div>
		<br>
		<div class="box">
			<div class="table-responsive">
				<table class="table table-bordered table-striped">
					<thead>
						<tr>
						<th>S.no</th>
						<th>Name</th>
						<th>Email</th>
						<th>Mobile Number</th>
						<th>Action</th>	
						</tr>
					</thead>
					<tbody>
						@php $count=$userlist->firstItem(); @endphp
						@forelse($userlist as $key=>$value)
							<tr>
								<td>{{ $count ++}}</td>
								<td>{{ $value->name or "---"}}</td>
								<td>{{ $value->email or "---"}}</td>
								<td>{{ $value->mobile_no or "---"}}</td>
								<td>
							<a href="{{ url('user-edit/'.$value->id) }}"><button class="btn btn-sm btn-primary disable-on-click">Edit</button></a>
                          	<button  type="button" class="btn btn-sm btn-danger user_delete" value="{{ $value->id }}">Delete</button>
								</td>	
							</tr>	
							@empty
							<tr><td colspan="5" align="center">No Records Found<td></tr>
							@endforelse
					</tbody>
				</table>
		</div>	
		<div class="pull-right">
				{{ $userlist->appends(Request::all())->links() }}
		</div>

</div>
{!! Form::open(array('url'=>'/user-delete/','method'=>'DELETE','id' =>'js-delete-user' )) !!}
{!! Form::hidden('id',null,array('id'=>'id')) !!}
{!! Form::close() !!}
@endsection
@section('footer')
 <script src="/js/jquery.min.js"></script>
 <script src="/js/toastr.js" text="text/javascript"></script>
 <script type="text/javascript">
 $(document).ready(function(){
 	$('.user_delete').on('click',function(){
      if(confirm("Are You Sure You Want to Delete")){
      	var id=this.value;
      	    var token = $("meta[name='csrf-token']").attr("content");
     	$.ajax({
      		url:"{{  url('/user-delete')}}",
      		type:"POST",
      		data:{'id':id,'_token':token},
      		success:function(){
      			alert('Delete success');
      		}
      	})
      }
    });
 })
  
  @if(\Session::has('success'))
  	  toastr.success("success","{{ Session::get('success') }}");
  	@endif
  	
</script>
@endsection
