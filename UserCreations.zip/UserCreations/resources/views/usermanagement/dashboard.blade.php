@extends('layouts.app')
<style type="text/css">
#contextMenu {
  position: absolute;
  display: none;
}
</style>
@section('content')
<div class="container">
	<div class="body">
	<div class="card">
		<div id="context_menus">
					<p><a href><b>Hi, When Right Click to Perform the Events</b></a></p>
		{!! Form::open(array('url'=>url('send-email-event'),'method'=>'get','id'=>'js-email-event')) !!}
		{!! Form::close() !!}
		<div>
	</div>
</div>
</div>	
@endsection
@section('footer')
 <script src="/js/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	//("div").oncontextmenu=function()
	$('#context_menus').contextmenu(function(){
		$('#js-email-event').submit();
	})
	
});


</script>
@endsection